# RideShare — run locally

1. Install Flask (one time):
   pip install flask

2. Start the server:
   python app.py

3. Open in your browser:
   http://127.0.0.1:5000

Data is stored in a local SQLite file `rideshare.db`, created automatically
on first run. Delete it any time to reset all accounts and rides.

## How to try it
- Open two browser windows (or one normal + one incognito).
- In window 1, sign up as a Rider.
- In window 2, sign up as a Driver, then flip the "Online" switch.
- In window 1, book a ride (tick "pooled" for the discounted shared fare).
- In window 2, accept it under "Nearby requests", then Start Trip, then
  Complete Trip.
- Both sides get prompted to rate each other after completion — ratings
  show up as a ★ badge next to each profile from then on.
