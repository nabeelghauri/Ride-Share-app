/* ============================================================
   RideShare front-end logic
   Talks to the Flask API and renders the rider / driver screens.
   ============================================================ */

const API = "/api";
const POLL_MS = 4000;

let currentUser = JSON.parse(localStorage.getItem("rs_user") || "null");
let pollTimer = null;
let pendingRatingRideId = null;
let selectedStars = 0;

// ---------------------------------------------------------------
// Fetch helper
// ---------------------------------------------------------------
async function api(path, options = {}) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || "Something went wrong");
  }
  return data;
}

// ---------------------------------------------------------------
// Auth screen wiring
// ---------------------------------------------------------------
const tabBtns = document.querySelectorAll(".tab-btn");
const loginForm = document.getElementById("login-form");
const registerForm = document.getElementById("register-form");

tabBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    tabBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    loginForm.classList.toggle("hidden", tab !== "login");
    registerForm.classList.toggle("hidden", tab !== "register");
  });
});

registerForm.querySelectorAll('input[name="role"]').forEach((radio) => {
  radio.addEventListener("change", () => {
    const isDriver = registerForm.role.value === "driver";
    document.getElementById("vehicle-field").classList.toggle("hidden", !isDriver);
    registerForm.vehicle.required = isDriver;
  });
});

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("login-msg");
  msg.textContent = "";
  msg.className = "form-msg";
  const fd = new FormData(loginForm);
  try {
    const user = await api("/login", {
      method: "POST",
      body: JSON.stringify({ email: fd.get("email"), password: fd.get("password") }),
    });
    setCurrentUser(user);
  } catch (err) {
    msg.textContent = err.message;
    msg.className = "form-msg error";
  }
});

registerForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("register-msg");
  msg.textContent = "";
  msg.className = "form-msg";
  const fd = new FormData(registerForm);
  try {
    const user = await api("/register", {
      method: "POST",
      body: JSON.stringify({
        name: fd.get("name"),
        email: fd.get("email"),
        password: fd.get("password"),
        role: fd.get("role"),
        vehicle: fd.get("vehicle"),
      }),
    });
    setCurrentUser(user);
  } catch (err) {
    msg.textContent = err.message;
    msg.className = "form-msg error";
  }
});

document.getElementById("logout-btn").addEventListener("click", () => {
  currentUser = null;
  localStorage.removeItem("rs_user");
  stopPolling();
  render();
});

// ---------------------------------------------------------------
// Screen switching
// ---------------------------------------------------------------
function setCurrentUser(user) {
  currentUser = user;
  localStorage.setItem("rs_user", JSON.stringify(user));
  render();
}

function render() {
  const authScreen = document.getElementById("auth-screen");
  const riderScreen = document.getElementById("rider-screen");
  const driverScreen = document.getElementById("driver-screen");
  const navUser = document.getElementById("nav-user");

  if (!currentUser) {
    authScreen.classList.remove("hidden");
    riderScreen.classList.add("hidden");
    driverScreen.classList.add("hidden");
    navUser.classList.add("hidden");
    return;
  }

  authScreen.classList.add("hidden");
  navUser.classList.remove("hidden");
  document.getElementById("nav-name").textContent =
    `${currentUser.name} · ${currentUser.role === "driver" ? "Driver" : "Rider"}`;
  updateNavRating();

  if (currentUser.role === "rider") {
    riderScreen.classList.remove("hidden");
    driverScreen.classList.add("hidden");
    refreshRiderScreen();
  } else {
    driverScreen.classList.remove("hidden");
    riderScreen.classList.add("hidden");
    document.getElementById("online-toggle").checked = currentUser.is_online;
    updateStatusLabel();
    refreshDriverScreen();
  }

  startPolling();
}

function updateNavRating() {
  const el = document.getElementById("nav-rating");
  if (currentUser.rating_count) {
    el.textContent = `★ ${currentUser.rating_avg} (${currentUser.rating_count})`;
  } else {
    el.textContent = "New";
  }
}

function startPolling() {
  stopPolling();
  pollTimer = setInterval(() => {
    if (!currentUser) return;
    if (currentUser.role === "rider") refreshRiderScreen();
    else refreshDriverScreen();
  }, POLL_MS);
}

function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
}

// ---------------------------------------------------------------
// Formatting helpers
// ---------------------------------------------------------------
function statusLabel(status) {
  return { requested: "Finding a driver", accepted: "Driver on the way",
    ongoing: "Trip in progress", completed: "Completed", cancelled: "Cancelled" }[status] || status;
}

function fmtRating(u) {
  return u && u.rating_count ? `★ ${u.rating_avg} (${u.rating_count})` : "New";
}

function rideCardHTML(ride, viewerRole) {
  const other = viewerRole === "rider" ? ride.driver : ride.rider;
  const otherLabel = viewerRole === "rider" ? "Driver" : "Rider";
  const otherInfo = other
    ? `${other.name} · ${fmtRating(other)}${other.vehicle ? " · " + other.vehicle : ""}`
    : "Waiting for a match…";

  return `
    <div class="ride-card" data-ride-id="${ride.id}">
      <div class="ride-route">
        <span class="dot">●</span> ${escapeHTML(ride.pickup)}
        <span class="arrow">→</span>
        <span class="dot">●</span> ${escapeHTML(ride.dropoff)}
      </div>
      <div class="ride-meta">
        <span class="pill status-${ride.status}">${statusLabel(ride.status)}</span>
        ${ride.pooled ? '<span class="pill pooled-pill">Pooled</span>' : ""}
        <span class="pill">$${ride.fare.toFixed(2)}</span>
        <span class="pill">${ride.distance_km} km</span>
      </div>
      <div class="ride-people">
        <span>${otherLabel}: ${otherInfo}</span>
      </div>
      <div class="ride-actions" data-actions></div>
    </div>
  `;
}

function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------------------------------------------------------------
// RIDER screen
// ---------------------------------------------------------------
const bookForm = document.getElementById("book-form");
bookForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = document.getElementById("book-msg");
  msg.textContent = "";
  msg.className = "form-msg";
  const fd = new FormData(bookForm);
  try {
    await api("/rides/request", {
      method: "POST",
      body: JSON.stringify({
        rider_id: currentUser.id,
        pickup: fd.get("pickup"),
        dropoff: fd.get("dropoff"),
        pooled: fd.get("pooled") === "on",
      }),
    });
    bookForm.reset();
    msg.textContent = "Ride requested — looking for a nearby driver.";
    msg.className = "form-msg success";
    refreshRiderScreen();
  } catch (err) {
    msg.textContent = err.message;
    msg.className = "form-msg error";
  }
});

async function refreshRiderScreen() {
  try {
    const history = await api(`/rides/history/${currentUser.id}`);
    const active = history.find((r) => ["requested", "accepted", "ongoing"].includes(r.status));
    const past = history.filter((r) => ["completed", "cancelled"].includes(r.status));

    const activeBox = document.getElementById("rider-active-ride");
    if (active) {
      activeBox.innerHTML = rideCardHTML(active, "rider");
      const actions = activeBox.querySelector("[data-actions]");
      if (active.status === "requested" || active.status === "accepted") {
        const btn = document.createElement("button");
        btn.className = "btn-danger";
        btn.textContent = "Cancel Ride";
        btn.onclick = () => cancelRide(active.id, "rider");
        actions.appendChild(btn);
      }
    } else {
      activeBox.innerHTML = '<p class="empty-state">No active ride. Book one above.</p>';
    }

    renderHistory("rider-history", past, "rider");
    maybePromptRating(past);
  } catch (err) {
    console.error(err);
  }
}

// ---------------------------------------------------------------
// DRIVER screen
// ---------------------------------------------------------------
document.getElementById("online-toggle").addEventListener("change", async (e) => {
  try {
    const user = await api(`/driver/${currentUser.id}/status`, {
      method: "POST",
      body: JSON.stringify({ is_online: e.target.checked }),
    });
    currentUser = user;
    localStorage.setItem("rs_user", JSON.stringify(user));
    updateStatusLabel();
    refreshDriverScreen();
  } catch (err) {
    alert(err.message);
    e.target.checked = !e.target.checked;
  }
});

function updateStatusLabel() {
  const label = document.getElementById("status-label");
  if (currentUser.is_online) {
    label.textContent = "Online";
    label.className = "pill status-online";
  } else {
    label.textContent = "Offline";
    label.className = "pill status-offline";
  }
}

async function refreshDriverScreen() {
  try {
    const history = await api(`/rides/history/${currentUser.id}`);
    const active = history.find((r) => ["accepted", "ongoing"].includes(r.status));
    const past = history.filter((r) => ["completed", "cancelled"].includes(r.status));

    const activeBox = document.getElementById("driver-active-ride");
    if (active) {
      activeBox.innerHTML = rideCardHTML(active, "driver");
      const actions = activeBox.querySelector("[data-actions]");

      if (active.status === "accepted") {
        const startBtn = document.createElement("button");
        startBtn.className = "btn-primary";
        startBtn.textContent = "Start Trip";
        startBtn.onclick = () => driverAction(`/rides/${active.id}/start`, "start");
        actions.appendChild(startBtn);

        const cancelBtn = document.createElement("button");
        cancelBtn.className = "btn-danger";
        cancelBtn.textContent = "Cancel";
        cancelBtn.onclick = () => cancelRide(active.id, "driver");
        actions.appendChild(cancelBtn);
      } else if (active.status === "ongoing") {
        const completeBtn = document.createElement("button");
        completeBtn.className = "btn-primary";
        completeBtn.textContent = "Complete Trip";
        completeBtn.onclick = () => driverAction(`/rides/${active.id}/complete`, "complete");
        actions.appendChild(completeBtn);
      }
    } else {
      activeBox.innerHTML = '<p class="empty-state">No active ride.</p>';
    }

    const availBox = document.getElementById("available-rides");
    if (!currentUser.is_online) {
      availBox.innerHTML = '<p class="empty-state">Go online to see ride requests.</p>';
    } else if (active) {
      availBox.innerHTML = '<p class="empty-state">Finish your current ride to see new requests.</p>';
    } else {
      const avail = await api("/rides/available");
      if (avail.length === 0) {
        availBox.innerHTML = '<p class="empty-state">No requests nearby right now.</p>';
      } else {
        availBox.innerHTML = avail.map((r) => {
          const html = rideCardHTML(r, "driver");
          return html;
        }).join("");
        availBox.querySelectorAll(".ride-card").forEach((card) => {
          const rideId = card.dataset.rideId;
          const actions = card.querySelector("[data-actions]");
          const btn = document.createElement("button");
          btn.className = "btn-primary";
          btn.textContent = "Accept Ride";
          btn.onclick = () => acceptRide(rideId);
          actions.appendChild(btn);
        });
      }
    }

    renderHistory("driver-history", past, "driver");
    maybePromptRating(past);
  } catch (err) {
    console.error(err);
  }
}

async function acceptRide(rideId) {
  try {
    await api(`/rides/${rideId}/accept`, {
      method: "POST",
      body: JSON.stringify({ driver_id: currentUser.id }),
    });
    refreshDriverScreen();
  } catch (err) {
    alert(err.message);
    refreshDriverScreen();
  }
}

async function driverAction(path, _label) {
  try {
    await api(path, { method: "POST", body: JSON.stringify({}) });
    refreshDriverScreen();
  } catch (err) {
    alert(err.message);
  }
}

async function cancelRide(rideId, by) {
  if (!confirm("Cancel this ride?")) return;
  try {
    await api(`/rides/${rideId}/cancel`, {
      method: "POST",
      body: JSON.stringify({ by }),
    });
    if (currentUser.role === "rider") refreshRiderScreen();
    else refreshDriverScreen();
  } catch (err) {
    alert(err.message);
  }
}

// ---------------------------------------------------------------
// Shared history rendering
// ---------------------------------------------------------------
function renderHistory(containerId, rides, viewerRole) {
  const box = document.getElementById(containerId);
  if (rides.length === 0) {
    box.innerHTML = '<p class="empty-state">No past rides yet.</p>';
    return;
  }
  box.innerHTML = rides.map((r) => rideCardHTML(r, viewerRole)).join("");
}

// ---------------------------------------------------------------
// Ratings
// ---------------------------------------------------------------
const ratedRideIds = new Set(JSON.parse(localStorage.getItem("rs_rated") || "[]"));

function saveRated() {
  localStorage.setItem("rs_rated", JSON.stringify([...ratedRideIds]));
}

function maybePromptRating(pastRides) {
  const toRate = pastRides.find(
    (r) => r.status === "completed" && !ratedRideIds.has(r.id)
  );
  if (toRate && !pendingRatingRideId && document.getElementById("rating-modal").classList.contains("hidden")) {
    openRatingModal(toRate.id, currentUser.role === "rider" ? "your driver" : "your rider");
  }
}

function openRatingModal(rideId, who) {
  pendingRatingRideId = rideId;
  selectedStars = 0;
  document.getElementById("rating-title").textContent = `Rate ${who}`;
  document.getElementById("rating-comment").value = "";
  document.querySelectorAll("#star-picker span").forEach((s) => s.classList.remove("active"));
  document.getElementById("rating-modal").classList.remove("hidden");
}

document.querySelectorAll("#star-picker span").forEach((star) => {
  star.addEventListener("click", () => {
    selectedStars = Number(star.dataset.value);
    document.querySelectorAll("#star-picker span").forEach((s) => {
      s.classList.toggle("active", Number(s.dataset.value) <= selectedStars);
    });
  });
});

document.getElementById("skip-rating").addEventListener("click", () => {
  if (pendingRatingRideId) ratedRideIds.add(pendingRatingRideId);
  saveRated();
  closeRatingModal();
});

document.getElementById("submit-rating").addEventListener("click", async () => {
  if (!selectedStars) {
    alert("Please pick a star rating first.");
    return;
  }
  try {
    const updated = await api(`/rides/${pendingRatingRideId}/rate`, {
      method: "POST",
      body: JSON.stringify({
        from_user: currentUser.id,
        stars: selectedStars,
        comment: document.getElementById("rating-comment").value,
      }),
    });
    ratedRideIds.add(pendingRatingRideId);
    saveRated();
    closeRatingModal();
    // if we rated ourselves somehow reflected, refresh own profile too
    if (updated.id === currentUser.id) {
      currentUser = updated;
      localStorage.setItem("rs_user", JSON.stringify(currentUser));
      updateNavRating();
    }
  } catch (err) {
    alert(err.message);
    closeRatingModal();
  }
});

function closeRatingModal() {
  pendingRatingRideId = null;
  document.getElementById("rating-modal").classList.add("hidden");
}

// ---------------------------------------------------------------
// Boot
// ---------------------------------------------------------------
render();
